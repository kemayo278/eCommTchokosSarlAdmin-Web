export interface User {
  id: number;
  name: string;
  email: string;
  phone: string | null;
  avatar: string | null;
  role: string;
  isActive: boolean;
  roles: string[];
  emailVerifiedAt: string | null;
  referralCode: string | null;
  hasUnlockedReferral: number;
  mustChangePassword: boolean;
  maxSelfAssignDeliveries: number;
  customer: unknown | null;
  createdAt: string;
  updatedAt: string;
}

export interface LoginResponse {
  user: User;
  token: string;
  must_change_password: boolean;
}
